package com.bdky.beerfinder.controllers;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bdky.beerfinder.models.User;
import com.bdky.beerfinder.services.UserService;
import com.bdky.beerfinder.validators.UserValidator;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;

@Controller
public class MainController {
	  private final UserService userService;
	  private final UserValidator userValidator;
	    
	    public MainController(UserService userService, UserValidator userValidator) {
	        this.userService = userService;
	        this.userValidator = userValidator;
	    }
	
//=================================
//		register page
//=================================
	
	@RequestMapping("/register")
	public String register(Model model) {
		model.addAttribute("user", new User());
		return "registration.jsp";
	}
	
	@RequestMapping(value="/registration", method=RequestMethod.POST)
	public String reg(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
		userValidator.validate(user, result);
		if(userService.findByEmail(user.getEmail()) != null) {
			result.rejectValue("email", "Unique", "Email already in use!");
		}
		
		if(result.hasErrors()) {
			return "registration.jsp";
		} else {
			User a = userService.registerUser(user);
			session.setAttribute("userId", a.getId());
			return "redirect:/beerfinder";
		}
	}
	
//=================================
//	login pages
//=================================
	
	@RequestMapping("/beerfinder/login")
	public String login() {
		return "login.jsp";
	}
	
	   @RequestMapping(value="/signin", method=RequestMethod.POST)
	    public String log(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session, RedirectAttributes redirectAttributes) {
	        if(userService.authenticateUser(email, password)) {
	        	User a = userService.findByEmail(email);
	        	session.setAttribute("userId", a.getId());
	        	return "redirect:/beerfinder";
	        } else {
	        	redirectAttributes.addFlashAttribute("logerr", "Invalid Credentials!");
	        	return "redirect:/beerfinder/login";
	        }
		   
	    }
	       
//=================================
//	google
//=================================	
	@RequestMapping("/")
	public String goo() {
		return "login2.jsp";
	}	

	  @RequestMapping(value="/home", method=RequestMethod.POST)
	    public String googleLog(@RequestParam("id_token") String idTokenString, HttpSession session) throws GeneralSecurityException, IOException {
		  
		  NetHttpTransport transport = new NetHttpTransport();
		  GsonFactory jsonFactory = new GsonFactory();
	
			GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
			// Specify the CLIENT_ID of the app that accesses the backend:
			.setAudience(Collections.singletonList("672380747652-3qvd422gi7d030er9div579nfrg02j74.apps.googleusercontent.com"))
			// Or, if multiple clients access the backend:
			//.setAudience(Arrays.asList(CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3))
			.build();
			
			// (Receive idTokenString by HTTPS POST)
			
			GoogleIdToken idToken = verifier.verify(idTokenString);
			if (idToken != null) {
			  Payload payload = idToken.getPayload();
			
			  // Print user identifier
			  String userId = payload.getSubject();
			  System.out.println("User ID: " + userId);
			
			  // Get profile information from payload
			  String email = payload.getEmail();
			  boolean emailVerified = Boolean.valueOf(payload.getEmailVerified());
			  String name = (String) payload.get("name");
			  String pictureUrl = (String) payload.get("picture");
			  String locale = (String) payload.get("locale");
			  String familyName = (String) payload.get("family_name");
			  String givenName = (String) payload.get("given_name");
			  
				} else {
				  System.out.println("Invalid ID token.");
				}
	        	
	        	return "redirect:/beerfinder/login";   
		   
	    }
	   
//=================================
//		home page
//=================================	
	
	@RequestMapping("/beerfinder")
	public String beerFinder() {
		return "home.jsp";
	}	
	  	  
//	@RequestMapping("/beerfinder")
//	public String home(Model model, HttpSession session, RedirectAttributes redirect) {
//		Long userId = (Long) session.getAttribute("userId");
//		model.addAttribute("user", userService.findUserById(userId));
//		return "home.jsp";
//	}
	
//=================================
//		logout 
//=================================	
		
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/beerfinder/login";
	}
	
//=================================
//	maps page 
//=================================		

	@RequestMapping("/beerlocator")
	public String beerLocator() {
		return "map.jsp";
	
	}
	
//=================================
//	Profile 
//=================================	

	@RequestMapping("/profile")
	public String profile() {
		return "profile.jsp";
	}



	
}
