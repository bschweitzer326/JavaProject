function initMap() {
 	map = new google.maps.Map(document.getElementById('map'), {
  	center: {lat: 42.35868816420411, lng: -71.06204279136281},
 	zoom: 16,
  	mapId: 'e662c3ba3351b724'
	});
	
	new google.maps.Marker({
	    position: {lat: 42.35868816420411, lng: -71.06204279136281},
	    map,
	    title: "Find Beer",
	    animation: google.maps.Animation.DROP
  	});
  

  

}

