package com.bdky.beerfinder.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.bdky.beerfinder.models.Beer;
import com.bdky.beerfinder.repositories.BeerRepo;

@Service
public class BeerService {

	private final BeerRepo beerRepo;
	
	public BeerService(BeerRepo beerRepo) {
		this.beerRepo = beerRepo;
	}
	// find Beer by id
	public Beer findBeerById (Long id) {
		Optional<Beer> b = beerRepo.findById(id);
		
		if(b.isPresent()) {
            return b.get();
    	} else {
    	    return null;
    	}
	}
	
// find all records of Beer
	public List<Beer> findAllBeers() {
		return beerRepo.findAll();
	}
	
	
//delete one Beer Record
	public void deleteOneBeer(Long id) {
		beerRepo.deleteById(id);
	}
	
	
	
//save Beer (for either create or update)
	
	public Beer saveBeer(Beer b) {
		return beerRepo.save(b);
	}
	
}
