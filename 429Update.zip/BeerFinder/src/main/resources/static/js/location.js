var map, infoWindow;

function initMap() {
	map = new google.maps.Map(document.getElementById('map'), options);
	
 	var options = {
  	center: {lat: 42.35868816420411, lng: -71.06204279136281},
 	zoom: 16,
  	mapId: 'e662c3ba3351b724'
	};
	
	map = new google.maps.Map(document.getElementById('map'), options);
	
	map.data.loadGeoJson(
    "https://storage.googleapis.com/mapsdevsite/json/google.json"
 	);
	
	/*markers*/
	new google.maps.Marker({
	    position: {lat: 42.35868816420411, lng: -71.06204279136281},
	    map,
	    title: "You are here",
	    animation: google.maps.Animation.DROP,
	    icon: {
	    	url: "/img/logo.svg",
	    	scaledSize: new google.maps.Size(42,33)
	    }
	    
  	});
	
	var input = document.getElementById('search');
	var searchBox = new google.maps.places.SearchBox(input);
	
	map.addListener('bounds_changed', function() {
	searchBox.setBounds(map.getBounds());
	});
	
	var markers = [];
	
	searchBox.addListener('places_changed', function() {
		var places = searchBox.getPlaces();
		
		if (places.length === 0)
			return;
			
		markers.forEach(function (s) {s.setMap(null); });
		markers = [];
		
		var bounds = new google.maps.LatLngBounds();
		
		places.forEach(function (p) {
			if (!p.geometry)
				return;
				
			markers.push(new google.maps.Marker({	
				map: map,
				title: p.name,			
				position: p.geometry.location,
				animation: google.maps.Animation.DROP
			}));
			
			if (p.geometry.viewport)
				bounds.union(p.geometry.viewport);
			else
				bounds.extend(p.geometry.location);
		});
		map.fitBounds(bounds);
	});
	
	/*geolocation1*/
	
	if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position){
          console.log(position);
          $.get( "http://maps.googleapis.com/maps/api/geocode/json?latlng="+ position.coords.latitude + "," + position.coords.longitude +"&sensor=false", function(data) {
            console.log(data);
          })
          var img = new Image();
          img.src = "https://maps.googleapis.com/maps/api/staticmap?center=" + position.coords.latitude + "," + position.coords.longitude + "&zoom=13&size=800x400&sensor=false";
          $('#output').html(img);
        });
        
    }
	
	/*geolocation2*/
	
	/*infoWindow = new google.maps.InfoWindow;
	
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPostion(function (m) {
		var position = {
			lat: m.coords.latitude,
			lng: m.coords.longitude,
		};
		infoWindow.setPosition(position);
		infoWindow.setContent('Your location');
		infoWindow.open(map);
	}, function () {
		handleLocationError('Geolocation service failed', map.center());
		})
	} else {
		handleLocationError('No geolocation available', map.center());
	} */
 }
  
/* function handleLocationError (content, position) {
 	infoWindow.setPosition(position);
 	infoWindow.setContent(content);
 	infoWindow.open(map);
 }*/
