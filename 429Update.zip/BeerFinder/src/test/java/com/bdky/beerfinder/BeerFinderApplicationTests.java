package com.bdky.beerfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeerFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
